<!DOCTYPE html>
<?php 
  session_start();
?>
<?php include 'dbconnect.php';?>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.0/css/font-awesome.css" integrity="sha512-72McA95q/YhjwmWFMGe8RI3aZIMCTJWPBbV8iQY3jy1z9+bi6+jHnERuNrDPo/WGYEzzNs4WdHNyyEr/yXJ9pA==" crossorigin="anonymous" referrerpolicy="no-referrer" />    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.5.3/css/bootstrap.min.css" integrity="sha512-oc9+XSs1H243/FRN9Rw62Fn8EtxjEYWHXRvjS43YtueEewbS6ObfXcJNyohjHqVKFPoXXUxwc+q1K7Dee6vv9g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <meta name="author" content="Ayoub Choukri">
    <link rel="shortcut icon" href="image/logo.ico" type="image/x-icon">
    <title>KILINA</title>
    <meta name="title" content="KILINA">
    <meta name="description" content="une marque Marocaine de prêt-à-porter.Nos vêtements ne sont pas limités à un certain âge, taille ou gamme de prix. La mode est pour tout le monde.">
    <meta name="keywords" content="vetement,tement,mode,fashion,style,shopping,model,vetements,clothes,tendance,robe,boutique,b,vetementfemme,femme,france,shop,chemise,instagood,love,fashionblogger,black,abidjan,blogueusemode,woman,beautiful,tements,fashionista,femme,woman,love,fashion,women,homme,mode,art,girl,beauty,france,photography,style,amour,lesbian,portrait,lgbt,instagood,lgbtq,paris,beautiful,queer,e,model,beaut,femmes,photo,instagram,makeup,habillement,tenue,outfitaddict,vetement,tunique,ideelook,tenuedujour,tendance,pretaporterfemme,modefemme ,zara,casualmode,outfits,outfitinspiration,mode,lookoftoday,look,ootdfashion,outfit,goodmood ,fashionstyle,fashionaddict,instafashion,workinggirl,avignon,blogger,influencer,bloggermode,fashionblogger,zarawoman ,style,basket,ootd,tatoogirl,closetinspo,womenstyle,goodvibes,outfitoftheday,zaraoutfit,whitevous,vetement,tement,mode,fashion,style,shopping,model,vetements,clothes,tendance,robe,boutique,b,vetementfemme,femme,france,shop,chemise,instagood,love,fashionblogger,black,abidjan,blogueusemode,woman,beautiful,tements,fashionista,beauty ,boutique,fashion,style,boutiqueshopping,shopping,ootd,shoplocal,onlineshopping,shopsmall,shop,moda,fashionblogger,onlineboutique,fashionista,smallbusiness,love,instafashion,fashionstyle,dress,boutiquefashion,boutiquestyle,instagood,clothing,clothes,accessories,handmade,beauty,summer,sale,instagram ,moda,fashion,style,modafeminina,estilo,love,look,o,tendencia,instagood,lookdodia,like,model,instagram,outfit,a,instafashion,brasil,shopping,fashionblogger,follow,fashionstyle,beauty,ootd,photography,fashionista,beautiful,photooftheday,k ">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="language" content="French">

</head>

