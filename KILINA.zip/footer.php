<style>.footer-footer a:hover{color:#fff}</style>
<footer class="animate__animated animate__fadeInUpBig">
<div class="container">
<div class="row">
<div style="display:grid" class="section1 col-md-6">
<h3>Kilina Collection</h3>
<p>
KILINA est une marque Marocaine de prêt-à-porter. <br>
Nos vêtements ne sont pas limités à un certain âge,
taille ou gamme de prix. La mode est pour tout le monde.<br>
KILINA la marque Marocaine la plus conviviale où les clients
peuvent obtenir des collections de style et de tendance. <br>
Nous accompagnons nos clients dans leurs choix de mode et dans l'élaboration de leur propre style
</p>
</div>
<div style="display:grid" class="section4 col-md-6">
<h4>NOUS CONTACTER</h4>
<div class="p-3">
<a target="blanc" href="mailto: kilina.maroc@gmail.com"><img src="image/emailb.png" alt=""></a>
<a target="blanc" href="https://www.facebook.com/Kilina.ma.officiel"><img src="image/facebookb.png" alt=""></a>
<a target="blanc" href="https://www.instagram.com/kilina.officiel/"><img src="image/instagramb.png" alt=""></a>
<a target="blanc" href="https://wa.me/0664937499"><img src="image/whatsappb.png" alt=""></a>
</div>
<div class="pl-5 text-left">
<h6>Fix Rabat : 05 30 02 44 53</h6>
<h6>Fix Sale : 08 08 5325 99</h6>
</div>
</div>
</div>
</div>
<div class="footer-footer text-center">
<p style="text-align:center">powered by <a target="blanck" href="https://www.tradeline-solutions.com/">Trade Line Solution</a> </p>
</div>
</footer>