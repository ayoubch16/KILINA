<?php 


$cnx = mysqli_connect("localhost","kilinama_root1","KILINAroot2022","kilinama_kilinaDB");
if(!$cnx) die(mysqli_connect_error());
else 


?>
